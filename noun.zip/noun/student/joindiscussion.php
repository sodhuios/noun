<?php
include 'head.php';
if(isset($_POST['send']) && !empty($_POST['message'])){
  $sender = $_SESSION['logged'];
  $d_id = $_GET['d_id'];
  $p_id = 'PS'.rand(100,999);
  $message = $_POST['message'] ;
  $query = "INSERT INTO post (`d_id`, `p_id`, `message`, `sender`, `p_time`) VALUES ('$d_id', '$p_id', '$message', '$sender', CURRENT_TIMESTAMP)";
  $result = mysqli_query($conn, $query);
  $_SESSION['id'] = $d_id;
  header('Refresh:0, viewforum.php');
}
?>
  
        <div class="container-left">
    	
        <ul class="menu-vertical">
            <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
          <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    
            </div>
         
 
       
        
               
    <div class="cpanels" style="background-color:color;">
    <center><h2 class="h-1">Join Discussion</h2></center>
        
        
    <div class="cpanels-in"> 
    
    <form method="post" action="" id="" class="">
     <div class="form-ui-panel">
        
        <div class="pan">
          <label>Message</label>
            <textarea name="message" type="" value=""  row="10" placeholder="Enter Message" id="" style="width: 60%; height: 50%;"></textarea>
          </div>
          
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="send" value="Send" style="float:right;">
          
                          </div>
            </center>
           </div>
                </form>
      
          </div>
            </div>
      
   </body>
</html>