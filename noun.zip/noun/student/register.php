<?php
if(isset($_POST['reg'])){
                $matric = $_POST['mn'];
                $surname = $_POST['sn'];
                $midname = $_POST['midname'];
                $firstname = $_POST['fn'];
                $sex = $_POST['sex'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $add = $_POST['add'];
                require_once('../conn.php');
                if($matric=="" || $phone==""){
                    echo "Missing Required Fields";
                }
                $query = "INSERT INTO student(`matric_no`, `surname`, `middlename`, `firstname`, `sex`, `phone`,`email`, `address`)
     VALUES ( '$matric', '$surname', '$midname','$firstname', '$sex', '$phone', '$email','$add')";
                $result = mysqli_query($conn, $query);
                session_start();
                    $_SESSION['logged'] = $matric;
					header('Refresh:0, dashboard.php');
                   
            }
?>
<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
 
</head>
<body style="overflow:hidden;">
<?php include "header.php";?>

<div style="background-repeat:no repeat; background-size:cover;height:10px;">
         <div>
    
    
    <div class="container">
              <div class="pull-right">
    

   <div class="container" style="text-align: center;">

   <div class="panel panel-default animated bounceIn" id="register-form" style="max-width: 380px; margin: 20 auto 20px; text-align: left;">

        <div class="panel-heading"><strong>Registration</strong></div>

        <div class="panel-body">
            
            <form id="" action="" method="post">
                
        <div style="display:none"><input type="hidden" value="" name=""></div>
           

            <div class="form-group">
                <input class="form-control" id="reg_no" placeholder="Matric. Number" name="mn" type="text"> </div>
            <div class="form-group">
                <input class="form-control" id="sn" placeholder="surname" name="sn" type="text"> </div>
            <div class="form-group">
                <input class="form-control" id="midname" placeholder="Middlename" name="midname" type="text"> </div>
            <div class="form-group">
                <input class="form-control" id="fn" placeholder="First Name" name="fn" type="text"> </div>
            <div class="form-group">
                <select class="form-control" name="sex" id="sex">
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>
            </div>
            <div class="form-group">
                <input class="form-control" id="phone" placeholder="Phone Number" name="phone" type="text"> </div>
            <div class="form-group">
                <input class="form-control" id="email" placeholder="Email Address" name="email" type="text"> </div>
            <div class="form-group">
                <input class="form-control" id="Address" placeholder="Home Address" name="add" type="textarea"> </div>
            
            <hr>
            <div class="row">
                <div class="col-md-4" style="color: white">
                    <input class="btn btn-large btn-pry" type="submit" name="reg" value="REGISTER">                </div>
            </div>

            </form>
        </div>

    </div>

    <br>

           

    
</div>
                 

                  </div>
</div>
               
</div>
 
        </div>
         <footer style=" background-color:green; height:50px; border-top: 10px ; margin-top:590px;">
  
     <center>
      <div class="privacy pull-center" ><span style="color:white ">Copyright @ 2016. NOUN e-Learning</span></div>
         </center>
  </div>
</footer>
    </body>
</html>