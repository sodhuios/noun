<?php
include 'head.php';
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
        	<li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    
            </div>
         
     <br>
                    <div class="toolbox"><a href="view_details.php"><img src="../img/icon/view.png"><br>View Details</a></div>
            <div class="toolbox"><a href="upload.php"><img src="../img/icon/subscribe.png"><br>Upload File</a></div>
                 
             
                    <div class="toolbox"><a href="downloads.php"><img src="../img/icon/view.png"><br>Download File</a></div>
             
                    <br><br>
        </div>
      </body>
</html>