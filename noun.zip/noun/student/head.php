<?php
    session_start();
    if (!isset($_SESSION['logged'])) {
        # code...
        header('Refresh:0, login.php'); 
    }
    $user = $_SESSION['logged'];
    require('../conn.php');
    $query = "SELECT * FROM student WHERE matric_no = '$user'";
    $result = mysqli_query($conn, $query);

    $row = mysqli_fetch_array($result);
?>
<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" media="screen">
    <link rel="stylesheet" href="../css/structure.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
 
  </head>
<body style="overflow:auto;" >
   
    <header style="background-image:url(../img/green.png); background-repeat:no repeat; background-size:cover; ">
       
      
 <div class="container clearfix">
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
            <h1 class="brand brand_"><a href="http://nou.edu.ng"><img alt="" src="../img/logo.png"> </a></h1>
               <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" style="border-color:white;">
                    <span class="sr-only" >Toggle navigation</span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                </button>
               
            </div>
               <div class="collapse navbar-collapse"  id="bs-example-navbar-collapse-1" >
                <ul class="nav navbar-nav">
                    <li>
                        <a href="../index.php">Home</a>
                    </li>
                    <li>
                        <a href="#">Welcome,<?php echo " ".$row['matric_no']; ?></a>
                    </li>
                </ul>
                
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div class="mar"><marquee  direction="right" style="color: green; background-color: FFF;">Welcome to the e-Learning Portal of the National Open University of Nigeria.</marquee></div> 
</header>