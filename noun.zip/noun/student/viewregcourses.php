<?php
include 'head.php';
include '../conn.php';
if (isset($_SESSION['logged'])) {
  $id = $_SESSION['logged'];
		$query = "SELECT * FROM student_courses WHERE matric_no = '$id'";
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
          <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
          <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    

                    
            </div>
         
 
       

       
    <div class="panel">
    <h2 class="h-1">View Registered Courses</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border" style="color: green;">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Matric Number </th>
                      <th width="188" scope="col">Surname</th>
                      <th width="188" scope="col">Middlename</th>
                      <th width="199" scope="col">First Name</th>
                      <th width="199" scope="col">Sex</th>
                      <th width="188" scope="col">Phone</th>
                      <th width="199" scope="col">Email</th>
                      <th width="199" scope="col">Address</th>
                      
                    </tr>
                     
                    <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row["matric_no"]; ?></td>
                                    <td><?php echo $row["surname"]; ?></td>
                                    <td><?php echo $row["middlename"]; ?></td>
                                    <td><?php echo $row["firstname"]; ?></td>
                                    <td><?php echo $row["sex"]; ?></td>
                                    <td><?php echo $row["phone"]; ?></td>
                                    <td><?php echo $row["email"]; ?></td>
                                    <td><?php echo $row["address"]; ?></td>
                                </tr>
                           <?php }
                        }
                        else
                            echo "There are no registered students yet.";
                            ?>
                   
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>
</body>
</html>
<?php
	}
    else
        header('Refresh:0, login.php');
?>