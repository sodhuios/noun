<?php
include 'head.php';
    if(isset($_POST['submit'])){
        $course = $_POST['course'];
        require_once('../conn.php');
        if($course==""){
            echo "Missing Required Fields";
        }
        $query = "SELECT * FROM discussion WHERE course_code='$course'";
        $result = mysqli_query($conn, $query);
        if (mysqli_affected_rows($conn) >= 1) {
            $_SESSION['course'] = $course;
            header('Refresh:0, viewdiscussions.php');
            //echo $_SESSION['logged'];   
        }
    }
?>
  
        <div class="container-left">
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    
                    
            </div>
         
   
      
   
    <div class="panels" style="background-color:color;">
    <center><h2 class="h-1">Select Discussion</h2></center>
        <div class="panels-in"> 
    
    <form method="post" action="" id="" class="">
     <div class="form-ui-panel">
        <div class="pane">
            
            <input type="text" name="course" id="course" placeholder="Enter the course whose discussions you want to view."/>
            
          </div>
          
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="submit" value="Submit">
          
                          </div>
            </center>
           </div>
                </form>
      
          </div>
            </div>
    </body>
</html>
