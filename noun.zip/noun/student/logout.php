<?php include 'head.php';?>
<?php
	session_start();
	if (isset($_SESSION['logged'])) {
		$id = $_SESSION['logged'];
		$query1 = "UPDATE `student` SET `status` = 'offline' WHERE `matric_no` = '$id'";
        $result1 = mysqli_query($conn, $query1);
		unset($_SESSION['logged']);
		header('Location: ../index.php');
	}


?>