<?php
include 'head.php';
include '../conn.php';
if (isset($_SESSION['course'])) {

        $course = $_SESSION['course'];
		$query = "SELECT * FROM course_materials WHERE course_code = '$course'";
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    

                    
            </div>
         
 
       

       
    <div class="panel">
    <h2 class="h-1">View Course Materials</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border" style="color: green;">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Material ID </th>
                      <th width="188" scope="col">Course Code</th>
                      <th width="188" scope="col">File</th>
                      <th width="199" scope="col">Lecturer</th>
                      
                    </tr>
                     
                    <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row["cm_id"]; ?></td>
                                    <td><?php echo $row["course_code"]; ?></td>
                                    <td><a href="../course-materials/<?php echo $row["filename"]; ?>" style="color: green;"><?php echo $row["filename"]; ?></a></td>
                                    <td><?php echo $row["lec_id"]; ?></td>
                                </tr>
                           <?php }
                        }
                        else
                            echo "There are no materials on this course.";
                            ?>
                   
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>
</body>
</html>
<?php
	}
    else
        header('Refresh:0, login.php');
?>