<?php
include 'head.php';
  if (isset($_SESSION['logged'])) {
    $ID = $_SESSION['logged'];
  
        require_once('../conn.php');
        if (isset($_POST['submit'])) {
          # code...
          $query1 = "SELECT * FROM student_course WHERE matric_no = '$ID'";
          $result1 = mysqli_query($conn, $query1);
          if (mysqli_affected_rows($conn) == 0) {
            $matric = $ID;
            if (!empty($_POST['course']) || count($_POST['course']) <= 3)
                $c = $_POST['course'];
             else {
                echo "You either have not selected a course or you have selected more course than allowed.";
            }
            if (count($_POST['course']) == 1){
                $c[1] = ""; $c[2] = "";
            }
            if (count($_POST['course']) == 2){
                $c[2] = "";
            }
            $query = "INSERT INTO student_course (`matric_no`, `course1`, `course2`, `course3`)
             VALUES ( '$matric', '$c[0]', '$c[1]','$c[2]')";
             $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
          }else{
            echo "This user has done course registration already.";
          }
        }
?>
  <html>
      <head>
        <title>NOUN e-Learning</title>
      </head>
      <body>
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
          <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>

    <?php 
      $queryA = "SELECT * FROM courses";
      $resultA = mysqli_query($conn, $queryA);
      if (mysqli_affected_rows($conn) > 0) {
    ?>
    <div class="panels"style="background-color:color;">
      <center><h2 class="h-1">Register Course</h2></center>
        <div class="panels-in"> 
          <form method="post" action="" id="" class="">
             <div class="form-ui-panel">
                 <table class="grid grid-border" style="color: green;">
                    <thead>
                        <tr>
                            <th>Select Course</th>
                            <th>Course Code</th>
                            <th>Course Title</th>
                            <th>Course Unit</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        while ($row = mysqli_fetch_array($resultA)) {
                            echo '<tr>'
                            . '<td><input type="checkbox" name="course[]" value="' . $row["course_code"] . '"/></td>'
                            . '<td>' . $row["course_code"] . '</td>'
                            . '<td>' . $row["course_title"] . '</td>'
                            . '<td>' . $row["course_unit"] . '</td>'
                            . '</tr>';
                        }
                        ?>
                        <tr>
                            <td colspan="4">N.B.: Please be informed that you cannot select more than 3 courses</td>
                        </tr>
                    </tbody>
                </table>       
                <br>
                <center>
                  <div class="col-md-12">
                      <input class="btn btn-large btn-pry" type="submit" name="submit" value="Register">
                
                  </div>
                </center>
             </div>
          </form>
          
        </div>
    </div>
   
    </body>
</html>
<?php
    }
}
else
  header('Refresh:0, login.php');
?>