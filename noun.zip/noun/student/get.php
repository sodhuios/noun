<?php
	include '../conn.php';
	$status = ""; $l = "";
	$query = "SELECT course_lec FROM courses WHERE course_code = '$course'";
	$result = mysqli_query($conn, $query);
	if (mysqli_affected_rows($conn) > 0) {
        while ($lec = mysqli_fetch_array($result)) {
        	$l .= $lec['course_lec'];
        }
    }
    $query = "SELECT status FROM lecturer WHERE lec_id = '$l'";
	$result = mysqli_query($conn, $query);
	if (mysqli_affected_rows($conn) > 0) {
        while ($ext = mysqli_fetch_array($result)) {
        	$status .= $ext['status'];
        }
    }
?>