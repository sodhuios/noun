<?php
include 'head.php';
include '../conn.php';
if (isset($_SESSION['course'])) {

        $course = $_SESSION['course'];
		$query = "SELECT * FROM assignment WHERE course_code = '$course'";
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
          <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    

                    
            </div>
         
 
       

       
    <div class="panel">
    <h2 class="h-1">View Assignments</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border" style="color: green;">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Assignment ID </th>
                      <th width="188" scope="col">Course Code</th>
                      <th width="188" scope="col">File Name</th>
                      <th width="199" scope="col">Lecturer</th>
                      <th width="199" scope="col">Submit</th>
                      
                    </tr>
                     
                    <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row["a_id"]; ?></td>
                                    <td><?php echo $row["course_code"]; ?></td>
                                    <td><a href="../assignments/<?php echo $row["filename"]; ?>" style="color: green;"><?php echo $row["filename"]; ?></a></td>
                                    <td><?php echo $row["lecturer"]; ?></td>
                                    <td><a href="uploadass.php?a_id=<?php echo $row["a_id"]; ?>" style="color: green;">Upload Assignment</a></td>
                                </tr>
                           <?php }
                        }
                        else
                            echo "There are no assignments on this course.";
                            ?>
                   
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>
</body>
</html>
<?php
	}
    else
        header('Refresh:0, selectassignment.php');
?>