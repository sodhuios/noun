<?php
include 'head.php';
  if (isset($_SESSION['logged'])) {
?>
  <html>
      <head>
        <title>NOUN e-Learning</title>
      </head>
      <body>
        <div class="container-left">
        
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="selectassignment.php">Select Assignment<span></span></a></li>
            <li><a href="selectdiscussions.php">Select Discussion<span></span></a></li>
            <li><a href="registercourse.php">Register Course<span></span></a></li> 
            <li><a href="viewcontacts.php">View Contacts<span></span></a></li> 
           <li><a href="selectcourse.php">Select Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>

       
    <div class="panels" style="background-color:color;">
    <center><h2 class="h-1">Upload Assignment</h2></center>
        <div class="panels-in"> 
            <?php
    function displayForm(){?>
    <form method="post" action="" id="" class="" enctype="multipart/form-data">
     <div class="form-ui-panel">
        <div class="pane">
            <input class="form-control" type="hidden" name="MAX_FILE_SIZE" value="500000000"/>
         
            <input class="form-control" type="file" name="file" id="file" value=""/>

            
          </div>
          
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="sendfile" value="Send File">
          
                          </div>
            </center>
           </div>
                </form>
            <?php
}
    function processForm(){
        $allowedExts = array("pdf", "doc", "docx");
        $exts = end(explode(".", $_FILES['file']['name']));
        if(isset($_FILES["file"]) and $_FILES["file"]["error"] == UPLOAD_ERR_OK){
            if(($_FILES["file"]["type"] != "application/pdf") && ($_FILES["file"]["type"] != "application/msword") && ($_FILES["file"]["type"] != "application/vnd.openxmlformats-officedocument.wordprocessingml.document")){
                echo "<p>Only files with the extensions: pdf, doc, or docx are accepted</p>";
            }
            elseif(!move_uploaded_file($_FILES["file"]["tmp_name"],
                "../assignments/".basename($_FILES["file"]["name"]))){
                echo "<p>Sorry, there was a problem uploading that file!</p>";
            }
            elseif(($_FILES["file"]["size"] < 2000000000) && in_array($exts, $allowedExts)){
                displayThanks();
            }
        }
        else{
            switch($_FILES["file"]["error"]){
                case UPLOAD_ERR_INI_SIZE:
                    $message = "The file is larger than the server allows.";
                    break;
                    
                case UPLOAD_ERR_FORM_SIZE:
                    $message = "The file is larger than the script allows.";
                    break;
                    
                case UPLOAD_ERR_NO_FILE:
                    $message = "No file was uploaded; make sure you choose a file to upload.";
                    break;
                    
                default:
                    $message = "Please contact your server administrator for help.";
            }
            
            echo "<p>Sorry, there was a problem uploading that file. $message</p>";
        }
    }
  function displayThanks(){
        ?>
        <h1>Thank You</h1>
        <p>Here's your file</p>
        <p><a href="dashboard.php">Click here to continue</a></p>

        
        <?php
        $sub_id = "SUB".rand(100,999);
        $a_id = $_GET['a_id'];
        $file = $_FILES["file"]["name"];
        $uploader = $_SESSION['logged'];
        include('../conn.php');
        $query = "INSERT INTO ass_submission (`sub_id`, `a_id`, `filename`, `matric_no`) VALUES ('$sub_id', '$a_id', '$file', '$uploader')";
        $result = mysqli_query($conn, $query);
    }
    
    
    
    if(isset($_POST["sendfile"])){
        processForm();
    }
    else{
        displayForm();
    }
    
    
    
    ?>

      
          </div>
            </div>
   
    </body>
</html>
<?php
}
else
  header('Refresh:0, login.php');
?>