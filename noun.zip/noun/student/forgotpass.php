<?php
    include '../conn.php';
    $error = "";
    if(isset($_POST['submit'])){
        $id = $_POST['studID'];
        if($id == ""){
            $error = "Invalid Username";
        }else{
            $query = "SELECT matric_no FROM student WHERE matric_no = '$id'";
            $result = mysqli_query($conn, $query);
            if(mysqli_affected_rows($conn) == 1){
                header('Refresh:0, createpass.php?id='.$id);
            }
            else{
                $error = "This Registration number does not exist";
            }
        }
    
    }
echo $error;
?>
<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
 
</head>
<body style="overflow:hidden;">
<header style="background-image:url(img/green.png); background-repeat:no repeat; background-size:cover; ">     
 <div class="container clearfix" >
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
           
               <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" style="border-color:white;">
                    <span class="sr-only" >Toggle navigation</span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                </button>
               
            </div>
               <div class="collapse navbar-collapse"  id="bs-example-navbar-collapse-1" >
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">HOME</a>
                    </li>
                   
                </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

 <div style="background-image:url(img/im.png); background-repeat:no repeat; background-size:cover;height:10px;">
         <div>
    
    <div class="container">
              <div class="pull-center" style="margin-top: -30px;">
    

<div class="container" style="text-align: center;">

    <div class="panel panel-default animated bounceIn" id="login-form" style="max-width: 380px; margin: 170 auto 20px; text-align: left;">

        <div class="panel-heading"><strong>Forgot Password</strong></div>

        <div class="panel-body">
            
            <form id="" action="" method="post">
                
        <div style="display:none"><input type="hidden" value="<?echo $error;?>" name="error"></div>
           
            <div class="form-group">
                Student Id:<input class="form-control" id=""  name="studID" type="text" required> 
            
<br>
          <center>  <div class="row">
                <div class="col-md-4">
                    <input class="btn btn-large btn-pry" type="submit" name="submit" value="SUBMIT">                </div>
               
            </div></center>

            </form>
        </div>

    </div>

    <br>
    
</div>
     </body>
</html>