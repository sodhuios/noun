<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/kwicks-slider.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>    
<script src="js/jquery.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.kwicks-1.5.1.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/touchTouch.jquery.js"></script>
<script>
if ($(window).width() > 1024) {
    document.write("<" + "script src='js/jquery.preloader.js'></" + "script>");
}
</script>
<script type="text/javascript" charset="utf-8">
    $(window).load(function() {
        $('.flexslider').flexslider();
    });
</script>
<script>
jQuery(window).load(function () {
    $x = $(window).width();
    if ($x > 1024) {
        jQuery("#content .row").preloader();
    }
    jQuery('.magnifier').touchTouch();
    jQuery('.spinner').animate({
        'opacity': 0
    }, 1000, 'easeOutCubic', function () {
        jQuery(this).css('display', 'none')
    });
});
</script>
	</head>
<body style="overflow:hidden;">
    <div class="spinner"></div>
 <?php include "header.php";?>
   
<div  >
  <div class="container">
       
    <div class="row">
      <div class="span12">
        <div class="flexslider" style="border-bottom: green solid;border-top: green solid;border-left: green solid;border-right: green solid; height: 650px; width: 1200px;">
          <ul class="slides">
            <li> <img src="img/slide-3.jpg" alt="" style="height: 650px; width: 1200px;"> </li>
            <li> <img src="img/slide-2.png" alt="" style="height: 650px; width: 1200px;"> </li>
            <li> <img src="img/slide-1.jpg" alt="" style="height: 650px; width: 1200px;"> </li>
            <li> <img src="img/slide-4.png" alt="" style="height: 650px; width: 1200px;"> </li>
            <li> <img src="img/slide-3.jpg" alt="" style="height: 650px; width: 1200px;"> </li>
          </ul>
        </div>
        </div>
      </div>
    </div>
  </div>
   
    <div>
        <center>
<span id="responsiveFlag"></span>
         <article class="span6" >
         <h1><span style="color:green"></span> </h1>
        </article>
             </div>
 
<footer style="background-image:url(img/green.png); border-top:6px;">
  <div class="container">
     <center>
      <div class="privacy pull-center" ><span style="color:white "> &copy; NOUN e-Learning 2016. <a href="http://www.nou.edu.ng"></a></span></div>
         </center>
  </div>
</footer>
</body>
</html>
        
    <script src="js/bootstrap.js"></script>
</body>
</html>