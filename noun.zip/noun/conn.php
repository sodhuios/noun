<?php
	$conn = mysqli_connect('localhost', 'root', '', 'noun');
	if(!$conn){
		echo "The problem is: ". mysql_error();
	}
?>