<?php
include 'head.php';
require_once('../conn.php');
        $ID = $_GET['matric'];
        $query2 = "SELECT * FROM student WHERE matric_no = '$ID'";
        $result = mysqli_query($conn, $query2);
            
?>  
<div class="container-left">
        
        <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
    <div class="panel">
    <h2 class="h-1">Student Details</h2>
    <div id="form">
      <?php while ($row = mysqli_fetch_array($result)){?>
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody>
                    <tr>
                        <td>Matric Number</td>
                        <td><?php echo $row["matric_no"];?></td>
                    </tr>
                     <tr>
                        <td>Surname</td>
                        <td><?php echo $row["surname"];?></td>
                    </tr>
                    <tr>
                        <td>Middle Name</td>
                        <td><?php echo $row["middlename"];?></td>
                    </tr>
                    <tr>
                        <td>First Name</td>
                        <td><?php echo $row["firstname"];?></td>
                    </tr>
                    <tr>
                        <td>Sex</td>
                        <td><?php echo $row["sex"];?></td>
                    </tr>
                    <tr>
                        <td>Phone Number</td>
                        <td><?php echo $row["phone"];?></td>
                    </tr>
                    <tr>
                        <td>E-mail Address</td>
                        <td><?php echo $row["email"];?></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td><?php echo $row["address"];?></td>
                    </tr>
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>
<?php 
}
?>
    </body>
</html>