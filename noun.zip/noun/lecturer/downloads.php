
<?php
include '../head.php';
include '../conn.php';
if (isset($_SESSION['logged'])) {
		$query = "SELECT * FROM uploads";
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	<div class="passport">
        	<div class="inside"><img src="../img/<?php echo $_SESSION['logged'].".jpg";?>"></div>
        </div>
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
          <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
            
                    
            </div>
   <div class="panel">
    <h2 class="h-1">View Project Updates</h2>
     <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody><tr>
                   
                      <th width="174" scope="col">File Name</th>
                      <th width="188" scope="col">Uploader</th>
                      
                    </tr>
                     
                    <?php
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><a href="../uploads/<?php echo $row["filename"]; ?>"><?php echo $row["filename"]; ?></a></td>
                                    <td><?php echo $row["uploader"]; ?></td>
                                </tr>
                           <?php }
                        }
                        else
                            echo "The topic database is empty";
                            ?>
                    
                   
                  
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>

    </div>
    <br class="clear">
</div>
   </body>
</html>
<?php
	}
    else
        header('Refresh:0, superlogin.php?id=3');
?>