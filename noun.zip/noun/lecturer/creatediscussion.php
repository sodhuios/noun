<?php
include 'head.php';
  if (isset($_SESSION['logged'])) {
    $ID = $_SESSION['logged'];
        $query0 = "SELECT * FROM lecturer WHERE lec_id = '$ID'";
        $result0 = mysqli_query($conn, $query);
        if (mysqli_affected_rows($conn) == 1) {
        
        require_once('../conn.php');
        if (isset($_POST['submit'])) {
          # code...
          $d_id = 'DS'.rand(100, 999);
          $cc = $_POST['cc'];
          $q = $_POST['q']; 
          $creator = $ID;
          echo $creator;
    if($d_id==""||$cc==""||$q==""||$creator==""){echo "Missing Field Required";}

   else{ $query = "INSERT INTO discussion (`d_id`, `course_code`, `dis_question`, `dis_creator`, `dis_time`)
     VALUES ( '$d_id','$cc', '$q', '$creator', CURRENT_TIMESTAMP)";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));                                                           
    header('Refresh:1 , viewdiscussions.php');}
  }
?>
  <html>
      <head>
        <title>NOUN e-Learning</title>
      </head>
      <body>
        <div class="container-left">
        
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>

       
    <div class="panels"style="background-color:color;">
    <center><h2 class="h-1">Create Discussion</h2></center>
        <div class="panels-in"> 
    <form method="post" action="" id="" class="">
     <div class="form-ui-panel">
         <div class="pane">
          <label>Course Code:</label>
            <input name="cc" type="text" id="cc">
         </div>
         
        <div class="pane">
          <label>Question:</label>
            <input type="text" name="q" id="q" />
          </div>
        
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="submit" value="Add">
          
                          </div>
            </center>
         </div>
                </form>
        
          </div>
   
    </body>
</html>
<?php
}
}
else
  header('Refresh:0, admin_login.php');
?>