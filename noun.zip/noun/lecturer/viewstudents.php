<?php
include 'head.php';
require_once('../conn.php');
	if (isset($_SESSION['logged'])) {
        $ID = $_SESSION['logged'];
		$query = "SELECT course_code FROM courses WHERE course_lec = '$ID'";
		$result2 = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
            while($get = mysqli_fetch_array($result2)){
                $c = $get['course_code'];
                $query2 = "SELECT matric_no FROM student_course WHERE course1 = '$c' OR course2 = '$c' OR course3 = '$c'";
                $result = mysqli_query($conn, $query2);
            
?>
  
        
        <div class="container-left">
    	
        <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
         
    
    <div class="panel">
    <h2 class="h-1">Student List</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Matric Number </th>
                      <th width="174" scope="col">Details </th>
                    </tr>
                     
                    <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row["matric_no"]; ?></td>
                                    <td><a href="viewstuddetails.php?matric=<?php echo $row["matric_no"]; ?>" style="color: green;">View Details</a></td>
                                </tr>
                           <?php }
                        }}
                        else
                            echo "No student has registered for your course as yet.";
                            ?>
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>

    </body>
</html>
<?php
	}
    else
        header('Refresh:1, superlogin.php');
?>