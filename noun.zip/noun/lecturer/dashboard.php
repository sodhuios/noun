<?php
include 'head.php';
?>
  
        <div class="container-left">
    	
 <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
        	<li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
         
    
       
        <br>
                    <div class="toolbox"><a href="viewAssignments.php"><img src="../img/icon/view.png"><br>View Assignments</a></div>
            <div class="toolbox"><a href="creatediscussion.php"><img src="../img/icon/subscribe.png"><br>Create Discussion</a></div>
                 
             
                    <div class="toolbox"><a href="viewstudents.php"><img src="../img/icon/view.png"><br>View Students</a></div>
             
                    <br><br>
        </div>
        </body>
</html>