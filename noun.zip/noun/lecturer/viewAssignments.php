
<?php
include 'head.php';
	if (isset($_SESSION['logged'])) {
        $ID = $_SESSION['logged'];
		$query = "SELECT * FROM assignment WHERE lecturer = '$ID'";
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
         <div class="container-left">
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
       
        
                 <div class="panel">
    <h2 class="h-1">Topics</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody><tr>
                        <th width="10" scope="col">SN</th>
                        <th width="100" scope="col">Assignment ID</th>
                        <th width="100" scope="col">Course Code</th>
                        <th width="100" scope="col">File Name</th>
                    </tr>
                     
                    <?php
                        $i = 0;
                            while ($row = mysqli_fetch_array($result)) {
                                echo '<tr>'
                                . '<td>' . ++$i . '</td>'
                                . '<td>' . $row["a_id"] . '</td>'
                                . '<td>' . $row["course_code"] . '</td>'
                                . '<td>' . $row["filename"] . '</td>'
                                . '</tr>';
                            }
                        }
                        else
                            echo "The assignment database is empty";
                            ?>
                   
                    
                   
                    
                   
                  
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>

    </div>
    <br class="clear">
</div>
   
    
    </body>
</html>
<?php
    }
?>