<?php
include 'head.php';
include '../conn.php';

    $id = $_GET['d_id'];
		$query = "SELECT * FROM post WHERE d_id = '$id' ORDER BY p_time DESC";
        $_SESSION['d_id'] = $id;
		$result = mysqli_query($conn, $query);
		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
        <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
            
                    

                    
            </div>
         
 
       

       
    <div class="panel">
    <h2 class="h-1">Forum View</h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border" style="color: green;">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Post ID </th>
                      <th width="188" scope="col">Message</th>
                      <th width="188" scope="col">Sender</th>
                      <th width="199" scope="col">Date and time of post</th>
                      
                    </tr>
                     <tr>
                         <td><a href="joindiscussion.php?d_id=<?php echo $id;?>" style="color: green;">Reply</a></td>
                         <td colspan="4"></td>
                     </tr>
                    <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {?>
                                <tr>
                                    <td><?php echo ++$i; ?></td>
                                    <td><?php echo $row["p_id"]; ?></td>
                                    <td><?php echo $row["message"]; ?></td>
                                    <td><?php echo $row["sender"]; ?></td>
                                    <td><?php echo $row["p_time"]; ?></td>
                                </tr>
                           <?php }
                        }
                        else
                            echo "There are no posts on this forum.";
                            ?>
                   
          </tbody></table>
      
      
      
    </div>
 <br class="clear">
    </div>
</body>
</html>
<?php
	
?>