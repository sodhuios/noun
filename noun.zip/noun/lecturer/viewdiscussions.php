
<?php
include 'head.php';
require_once('../conn.php');
	if (isset($_SESSION['logged'])) {
        $ID = $_SESSION['logged'];
        $query0 = "SELECT * FROM lecturer WHERE lec_id = '$ID'";
        $result0 = mysqli_query($conn, $query0);
        if (mysqli_affected_rows($conn) == 1) {
    		$query = "SELECT * FROM discussion WHERE dis_creator = '$ID'";
    		$result = mysqli_query($conn, $query);
    		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewstudents.php">View Students<span></span></a></li>
            <li><a href="viewAssignments.php">View Assignments<span></span></a></li>
            <li><a href="upload.php">Upload Course Materials<span></span></a></li>
            <li><a href="creatediscussion.php">Create Discussion<span></span></a></li>
            <li><a href="viewdiscussions.php">View Discussions<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
        
                <div class="panel">
    <h2 class="h-1">Discussions </h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Discussion ID</th>
                      <th width="188" scope="col">Course Code</th>
                      <th width="199" scope="col">Discussion Question</th>
                     <th width="199" scope="col">Course Lecturer</th>
                     <th width="199" scope="col">Date Created</th>
                     <th width="199" scope="col">View Forum</th>
                    </tr>
                    
                       
                         <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {
                                echo '<tr>'
                                . '<td>' . ++$i . '</td>'
                                . '<td>' . $row["d_id"] . '</td>'
                                . '<td>' . $row["course_code"] . '</td>'
                                . '<td>' . $row["dis_question"] . '</td>'
                                . '<td>' . $row["dis_creator"] . '</td>'
                                . '<td>' . $row["dis_time"] . '</td>'
                                . '<td><a style= color: green;" href="viewforum.php?d_id=' . $row["d_id"] . '">View Forum</a></td>'
                                . '</tr>';
                            }
                        }
                    }
                            ?>
          </tbody></table>
  
    </div>
 <br class="clear">
    </div>

    </div>
    <br class="clear">
</div>
    </body>
</html>
<?php
	}
?>