 <header style="background-image:url(../img/green.png); background-repeat:no repeat; background-size:cover; ">
       
      
 <div class="container clearfix">
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
            <h1 class="brand brand_"><a href="http://nou.edu.ng"><img alt="" src="../img/logo.png"> </a></h1>
               <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" style="border-color:white;">
                    <span class="sr-only" >Toggle navigation</span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                </button>
               
            </div>
               <div class="collapse navbar-collapse"  id="bs-example-navbar-collapse-1" >
                <ul class="nav navbar-nav">
                    <li>
                        <a href="../index.php">Home</a>
                    </li>
                    <li>
                        <a href="../admin/login.php">Admin</a>
                    </li>
                    <li>
                        <a href="../student/login.php">Student</a>
                    </li>
                     <li>
                        <a href="#">Lecturer</a>
                    </li>
                </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div class="mar"><marquee  direction="right" style="color: green; background-color: FFF;">Welcome to the e-Learning Portal of the National Open University of Nigeria.</marquee></div> 
</header>
