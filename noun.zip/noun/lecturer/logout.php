<?php
include 'head.php';
session_start();
if(isset($_SESSION['logged'])){
	$id = $_SESSION['logged'];
	$query1 = "UPDATE `lecturer` SET `status` = 'offline' WHERE `lec_id` = '$id'";
    $result1 = mysqli_query($conn, $query1);
	unset($_SESSION['logged']);
	header('Location: ../index.php');
}
?>