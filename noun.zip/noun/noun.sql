-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2016 at 04:23 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `noun`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `username`, `password`) VALUES
(1, 'eldivinos', 'fashanudone');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `a_id` varchar(6) NOT NULL,
  `course_code` varchar(6) NOT NULL,
  `filename` text NOT NULL,
  `lecturer` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`a_id`, `course_code`, `filename`, `lecturer`) VALUES
('ASS980', 'CSC419', 'CSC514 Group Term Project.pdf', 'NOU156');

-- --------------------------------------------------------

--
-- Table structure for table `ass_submission`
--

CREATE TABLE `ass_submission` (
  `sub_id` varchar(6) NOT NULL,
  `a_id` varchar(6) NOT NULL,
  `filename` text NOT NULL,
  `matric_no` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ass_submission`
--

INSERT INTO `ass_submission` (`sub_id`, `a_id`, `filename`, `matric_no`) VALUES
('SUB857', 'ASS980', 'References Bibliography Harvard style.pdf', '100805066');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(6) NOT NULL,
  `course_title` text NOT NULL,
  `course_unit` varchar(1) NOT NULL,
  `course_lec` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_code`, `course_title`, `course_unit`, `course_lec`) VALUES
('CSC210', 'Software Engineering', '3', 'NOU178'),
('CSC419', 'Introduction to Computer Gaming', '3', 'NOU156');

-- --------------------------------------------------------

--
-- Table structure for table `course_materials`
--

CREATE TABLE `course_materials` (
  `cm_id` varchar(6) NOT NULL,
  `course_code` varchar(6) NOT NULL,
  `filename` text NOT NULL,
  `lec_id` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_materials`
--

INSERT INTO `course_materials` (`cm_id`, `course_code`, `filename`, `lec_id`) VALUES
('CM560', 'CSC419', 'JS1 Maths Third Term.docx', 'NOU156'),
('CM815', 'CSC419', 'Intro_to_Prolog3.pdf', 'NOU156');

-- --------------------------------------------------------

--
-- Table structure for table `discussion`
--

CREATE TABLE `discussion` (
  `d_id` varchar(5) NOT NULL,
  `course_code` varchar(6) NOT NULL,
  `dis_question` text NOT NULL,
  `dis_creator` varchar(7) NOT NULL,
  `dis_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discussion`
--

INSERT INTO `discussion` (`d_id`, `course_code`, `dis_question`, `dis_creator`, `dis_time`) VALUES
('DS159', 'CSC419', 'What are the different classes of computer games?', 'NOU156', '2016-07-16 00:07:41'),
('DS525', 'CSC419', 'What is computer gaming?', 'NOU156', '2016-07-16 00:08:43'),
('DS675', 'CSC210', 'What is the essence of computing?', 'NOU178', '2016-07-16 13:43:47');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lec_id` varchar(7) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `sex` text NOT NULL,
  `phone` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(16) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lec_id`, `fname`, `mname`, `lname`, `sex`, `phone`, `email`, `password`, `status`) VALUES
('NOU156', 'John', 'Oluwaremi', 'Aderibigbe', 'Male', '08123450989', 'adejohn@nou.edu.ng', 'aderibigbe', 'offline'),
('NOU178', 'Chinedu', 'Charles', 'Nwakali', 'M', '08178982245', 'ccnwakali@nou.edu.ng', 'nwakali', 'offline');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `username`, `msg`) VALUES
(1, 'sam', 'welcome'),
(2, 'sam', 'welcome'),
(3, 'sam', 'welcome'),
(4, 'sam', 'welcome'),
(5, 'sam', 'welcome'),
(6, 'sam', 'welcome'),
(7, 'sam', 'welcome'),
(8, 'sam', 'welcome'),
(9, 'sam', 'welcome'),
(10, 'sam', 'welcome'),
(11, 'sam', 'welcome'),
(12, 'sam', 'hi'),
(13, 'hitler', 'deadman'),
(14, 'hitler', 'deadman'),
(15, 'hitler', 'deadman'),
(16, 'sam', 'hi'),
(17, 'Fred', 'Sam'),
(18, 'john', 'hello'),
(19, 'john', 'hello'),
(20, 'john', 'hello'),
(21, 'john', 'hello'),
(22, 'john', 'hello'),
(23, 'john', 'hello'),
(24, 'Saint', 'look'),
(25, 'john', 'hello'),
(26, 'sam', 'fresh'),
(27, 'sam', 'hi'),
(28, 'fresh', 'Welcome to freshman year'),
(29, 'sammy', 'Hi');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `d_id` varchar(6) NOT NULL,
  `p_id` varchar(6) NOT NULL,
  `message` text NOT NULL,
  `sender` varchar(9) NOT NULL,
  `p_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`d_id`, `p_id`, `message`, `sender`, `p_time`) VALUES
('DS159', 'PS279', 'I want to ask a question sir.', '100805066', '2016-07-20 13:32:15'),
('DS159', 'PS295', 'How are you today?', 'NOU156', '2016-07-20 13:28:32'),
('DS159', 'PS328', 'What is the essence of gaming?', '100805066', '2016-07-20 13:47:00'),
('DS159', 'PS345', 'welcome 123456', 'NOU156', '2016-07-20 14:04:58'),
('DS159', 'PS385', 'Hello Sir', '100805066', '2016-07-20 13:16:08'),
('DS159', 'PS389', 'How do we minimise it?', '100805066', '2016-07-20 13:49:03'),
('DS159', 'PS400', 'Yes go ahead.', 'NOU156', '2016-07-20 13:36:28'),
('DS675', 'PS462', 'Computing is very important in human life.', '100805066', '2016-07-16 13:44:59'),
('DS159', 'PS501', 'Be careful to do your bit.', 'NOU156', '2016-07-20 13:53:24'),
('DS525', 'PS524', 'Welcome to what we know', '100805066', '2016-07-16 09:26:28'),
('DS159', 'PS527', 'Gaming is essential as it helps us to relax.', 'NOU156', '2016-07-20 13:48:01'),
('', 'PS541', 'Be careful to do your bit.', 'NOU156', '2016-07-20 13:57:00'),
('DS159', 'PS566', 'Time yourself and be disciplined.', 'NOU156', '2016-07-20 13:51:05'),
('DS159', 'PS627', 'okay', 'NOU156', '2016-07-20 13:59:56'),
('DS525', 'PS649', 'Computer gaming is the art and act of playing video games on the all-purpose general pc.', '100805066', '2016-07-16 06:11:24'),
('', 'PS672', 'Be careful to do your bit.', 'NOU156', '2016-07-20 13:56:38'),
('DS159', 'PS701', 'Welcome', '100805066', '2016-07-20 10:04:47'),
('DS159', 'PS723', 'Welcome', '100805066', '2016-07-20 10:40:27'),
('DS525', 'PS735', 'What is all these shinaniggans?', '100805066', '2016-07-16 09:27:00'),
('DS159', 'PS855', 'whaooow', 'NOU156', '2016-07-20 14:00:30'),
('DS159', 'PS886', 'Okay sir.', '100805066', '2016-07-20 13:48:40'),
('DS159', 'PS952', 'hello', '123456', '2016-07-20 14:04:33'),
('DS159', 'PS956', 'Welcome', '100805066', '2016-07-20 10:41:58');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `matric_no` varchar(9) NOT NULL,
  `surname` text NOT NULL,
  `middlename` text NOT NULL,
  `firstname` text NOT NULL,
  `sex` text NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`matric_no`, `surname`, `middlename`, `firstname`, `sex`, `phone`, `email`, `address`, `status`) VALUES
('100705043', 'Ekemini', 'Abasi', 'John', 'M', '08142547687', 'jekemini@yahoo.com', '12, Oshodi street, Oshodi, Lagos.', 'offline'),
('100805066', 'Oyeniran', 'Oluwadamilola', 'Samuel', 'M', '08106845835', 'dammyyoung@gmail.com', '28, Iresi street, Orile Agege, Lagos.', 'offline'),
('100805067', 'Ozioma', 'Paul', 'Amaka', 'F', '08127893454', 'pozioma@gmail.com', 'Km 14, Ore road, Ojo, Lagos state.', 'offline'),
('100809023', 'Makinde', 'Ojo', 'Paul', 'M', '08100982342', 'pomakinde@nou.edu.ng', '12, Okewoye street, off Apata, Somolu', 'offline'),
('123456', 'RInde', 'Bolaji', 'Saul', 'M', '08198906567', 'a@rindex.com', '3, solanke, oshodi', 'offline');

-- --------------------------------------------------------

--
-- Table structure for table `student_course`
--

CREATE TABLE `student_course` (
  `matric_no` varchar(9) NOT NULL,
  `course1` varchar(6) NOT NULL,
  `course2` varchar(6) NOT NULL,
  `course3` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_course`
--

INSERT INTO `student_course` (`matric_no`, `course1`, `course2`, `course3`) VALUES
('100705043', 'CSC419', 'CSC210', 'CSC321'),
('100805066', 'CSC210', 'CSC419', ''),
('100805067', 'CSC419', 'CSC210', 'CSC321'),
('123456', 'CSC210', 'CSC419', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `ass_submission`
--
ALTER TABLE `ass_submission`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `course_materials`
--
ALTER TABLE `course_materials`
  ADD PRIMARY KEY (`cm_id`);

--
-- Indexes for table `discussion`
--
ALTER TABLE `discussion`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lec_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`matric_no`);

--
-- Indexes for table `student_course`
--
ALTER TABLE `student_course`
  ADD PRIMARY KEY (`matric_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
