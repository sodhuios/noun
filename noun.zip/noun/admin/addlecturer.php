<?php
include 'head.php';
  if (isset($_SESSION['logged'])) {
    $ID = $_SESSION['logged'];
        $query0 = "SELECT * FROM admin WHERE username = '$ID'";
        $result0 = mysqli_query($conn, $query);
        if (mysqli_affected_rows($conn) == 1) {
  
        require_once('../conn.php');
        if (isset($_POST['submit'])) {
          # code...
          $lecID = $_POST['lid'];
          $sname = $_POST['sname'];
          $mname = $_POST['mname']; 
          $fname = $_POST['fname'];
          $gender = $_POST['gender'];       
          $gsm = $_POST['gsm'];
          $email = $_POST['email'];
          $pass = strtolower($sname);
    if($sname==""||$fname==""||$email==""){echo "Missing Field Required";}

   else{ $query = "INSERT INTO lecturer (`lec_id`, `fname`, `mname`, `lname`, `sex`, `phone`,`email`, `password`)
     VALUES ( '$lecID', '$fname', '$mname','$sname', '$gender', '$gsm', '$email','$pass')";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));                                                           
    header('Refresh:1 , viewlecturers.php?');}
  }
?>
  <html>
      <head>
        <title>NOUN e-Learning</title>
      </head>
      <body>
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewlecturers.php">View Lecturers<span></span></a></li>
            <li><a href="addlecturer.php">Add Lecturer<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>

       
    <div class="panels"style="background-color:color;">
    <center><h2 class="h-1">Add Lecturer</h2></center>
        <div class="panels-in"> 
    <form method="post" action="" id="" class="">
     <div class="form-ui-panel">
         <div class="pane">
          <label>Staff Id:</label>
            <input name="lid" type="text" id="">
         </div>
         
        <div class="pane">
          <label>Surname:</label>
            <input type="text" name="sname" id="sname" />
          </div>
          
        <div class="pane">
          <label for="fname">First Name:</label>
              <input type="text" name="fname" id="fname" />
        </div>
         
        <div class="pane">
          <label for="mname">Middle Name:</label>
              <input type="text" name="mname" id="mname" />
         </div>

        
        
        <div class="pane">
          <label>Gender:*</label>
            <select name="gender" id="gender">
                <option value="M">Male</option>
                <option value="F">Female</option>
            </select>
        </div>
        <div class="pane">
          <label>Email Address:</label>
            <input type="text" name="email" id="email" />
         </div>
        
         <div class="pane">
          <label>Phone number:</label>
            <input type="text" name="gsm" id="gsm" />
         </div>
        
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="submit" value="Add">
          
                          </div>
            </center>
         </div>
                </form>
        
          </div>
   
    </body>
</html>
<?php
}
}
else
  header('Refresh:0, login.php');
?>