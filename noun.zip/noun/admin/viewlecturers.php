
<?php
include 'head.php';
require_once('../conn.php');
	if (isset($_SESSION['logged'])) {
        $ID = $_SESSION['logged'];
        $query0 = "SELECT * FROM admin WHERE username = '$ID'";
        $result0 = mysqli_query($conn, $query0);
        if (mysqli_affected_rows($conn) == 1) {
    		$query = "SELECT * FROM lecturer";
    		$result = mysqli_query($conn, $query);
    		if (mysqli_affected_rows($conn) > 0) {
?>
  
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewlecturers.php">View Lecturers<span></span></a></li>
            <li><a href="addlecturer.php">Add Lecturer<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>
        
                <div class="panel">
    <h2 class="h-1">List of Lecturers </h2>
    <div id="form">
      
    <table border="0" cellspacing="0" cellpadding="0" class="grid grid-border">
                    <tbody><tr>
                    <th width="10" scope="col">SN</th>
                      <th width="174" scope="col">Lecturer ID</th>
                      <th width="188" scope="col">Firstname</th>
                      <th width="199" scope="col">Middlename</th>
                     <th width="199" scope="col">Lastname</th>
                        <th width="199" scope="col">Gender</th>
                        <th width="180" scope="col">Email</th>
                        <th width="174" scope="col">Phome Number</th>
                    </tr>
                    
                       
                         <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {
                                echo '<tr>'
                                . '<td>' . ++$i . '</td>'
                                . '<td>' . $row["lec_id"] . '</td>'
                                . '<td>' . $row["fname"] . '</td>'
                                . '<td>' . $row["mname"] . '</td>'
                                . '<td>' . $row["lname"] . '</td>'
                                . '<td>' . $row["sex"] . '</td>'
                                . '<td>' . $row["email"] . '</td>'
                                . '<td>' . $row["phone"] . '</td>'
                                . '</tr>';
                            }
                        }
                    }
                            ?>
          </tbody></table>
  
    </div>
 <br class="clear">
    </div>

    </div>
    <br class="clear">
</div>
    </body>
</html>
<?php
	}
?>