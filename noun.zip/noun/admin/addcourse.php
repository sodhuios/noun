<?php
include 'head.php';
  if (isset($_SESSION['logged'])) {
    $ID = $_SESSION['logged'];
        $query0 = "SELECT * FROM admin WHERE username = '$ID'";
        $result0 = mysqli_query($conn, $query);
        if (mysqli_affected_rows($conn) == 1) {
  
        require_once('../conn.php');
        if (isset($_POST['submit'])) {
          # code...
          $cc = $_POST['cc'];
          $ct = $_POST['ct'];
          $cu = $_POST['cu']; 
          $cl = $_POST['cl'];
    if($cc==""||$ct==""||$cu==""||$cl==""){echo "Missing Field Required";}

   else{ $query = "INSERT INTO courses (`course_code`, `course_title`, `course_unit`, `course_lec`)
     VALUES ( '$cc', '$ct', '$cu','$cl')";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));                                                           
    header('Refresh:1 , viewcourses.php');}
  }
?>
  <html>
      <head>
        <title>NOUN e-Learning</title>
      </head>
      <body>
        <div class="container-left">
    	
       <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewlecturers.php">View Lecturers<span></span></a></li>
            <li><a href="addlecturer.php">Add Lecturer<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>

                    
            </div>

       
    <div class="panels"style="background-color:color;">
    <center><h2 class="h-1">Add Course</h2></center>
        <div class="panels-in"> 
    <form method="post" action="" id="" class="">
     <div class="form-ui-panel">
         <div class="pane">
          <label>Course Code:</label>
            <input name="cc" type="text" id="cc">
         </div>
         
        <div class="pane">
          <label>Course Title:</label>
            <input type="text" name="ct" id="ct" />
          </div>
         
        <div class="pane">
          <label>Course Unit:*</label>
            <select name="cu" id="cu">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
            </select>
        </div>
        <div class="pane">
          <label for="mname">Course Lecturer:</label>
              <input type="text" name="cl" id="cl" />
         </div>
        
          
          
            <br>
            <center>
            <div class="col-md-12">
                    <input class="btn btn-large btn-pry" type="submit" name="submit" value="Add">
          
                          </div>
            </center>
         </div>
                </form>
        
          </div>
   
    </body>
</html>
<?php
}
}
else
  header('Refresh:0, admin_login.php');
?>