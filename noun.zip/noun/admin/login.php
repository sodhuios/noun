<?php
if(isset($_POST['login'])){
                $username = $_POST['username'];
                $pword = $_POST['password'];
                require_once('../conn.php');
                if($username=="" || $pword==""){
                    echo "Missing Required Fields";
                }
                $query = "SELECT username, password FROM admin WHERE username='$username' AND password='$pword'";
                $result = mysqli_query($conn, $query);
                session_start();
                if (mysqli_affected_rows($conn) == 1) {
                    $_SESSION['logged'] = $username;
					header('Refresh:0, dashboard.php');
					echo $_SESSION['logged'];
                }    
            }
?>

<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
 
</head>
<body style="overflow:hidden;">
<?php include "header.php";?>

<div style="background-repeat:no repeat; background-size:cover;height:10px;">
         <div>
    
    
    <div class="container">
              <div class="pull-right">
    

   <div class="container" style="text-align: center;">

   <div class="panel panel-default animated bounceIn" id="login-form" style="max-width: 380px; margin: 170 auto 20px; text-align: left;">

        <div class="panel-heading"><strong>Admin Login</strong></div>

        <div class="panel-body">
            
            <form id="" action="" method="post">
                
        <div style="display:none"><input type="hidden" value="" name=""></div>
           

            <div class="form-group">
                <input class="form-control" id="username" placeholder="Username" name="username" type="text" required> </div>

            <div class="form-group">
                <input class="form-control" id="pass" placeholder="Password" name="password" type="password" required></div>

            <div class="checkbox regular-checkbox-container">
            <div class="regular-checkbox-clear"></div></div>

            <hr>
            <div class="row">
                <div class="col-md-4" style="color: white">
                    <input class="btn btn-large btn-pry" type="submit" name="login" value="LOGIN">                </div>
                <div class="col-md-8 text-right" style="color: green;">
                    <small>
                        Forgot your password? <a href="../forgotpass.php"><br>Create a new one.</a>
                    </small>
                </div>
            </div>

            </form>
        </div>

    </div>

    <br>

           

    
</div>
                 

                  </div>
</div>
               
</div>
 
        </div>
         <footer style=" background-color:green; height:50px; border-top: 10px ; margin-top:590px;">
  
     <center>
      <div class="privacy pull-center" ><span style="color:white ">Copyright @ 2016. NOUN e-Learning</span></div>
         </center>
  </div>
</footer>
    </body>
</html>