<?php
include 'head.php';
include '../conn.php';
        if(isset($_POST['change'])){
            $id = $_SESSION['logged'];
            $opass = $_POST['pass'];
            $pass = $_POST['npass'];
            $cpass = $_POST['cnpass'];
            $query0 = "SELECT password FROM admin WHERE username='$id' AND password='$opass'";
            $result0 = mysqli_query($conn, $query0);
            if(mysqli_affected_rows($conn) == 1){
                if($pass == $cpass){
                    $query = "UPDATE admin SET password='$pass' WHERE username='$id'";
                    $result = mysqli_query($conn, $query);
                    header("Refresh:0, login.php");
                }
                else{ echo "INCORRECT PASSWORD";}
            }
        }
?>
<html>
<head>
<title>NOUN e-Learning</title>  
<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/touchTouch.css" type="text/css" media="screen">
<link rel="stylesheet" href="../css/kwicks-slider.css" type="text/css" media="screen">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
 
</head>
<body style="overflow:hidden;">
<header style="background-image:url(../img/green.png); background-repeat:no repeat; background-size:cover; ">     
 <div class="container clearfix" >
    <div class="row">
      <div class="span12">
        <div class="navbar navbar_">
          <div class="container">
           
               <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" style="border-color:white;">
                    <span class="sr-only" >Toggle navigation</span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                    <span class="icon-bar" style="background-color:white;"></span>
                </button>
               
            </div>
               <div class="collapse navbar-collapse"  id="bs-example-navbar-collapse-1" >
                <ul class="nav navbar-nav">
                    <li>
                        <a href="logout.php">Logout</a>
                    </li>
                   
                </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

 <div style="background-image:url(../img/im.png); background-repeat:no repeat; background-size:cover;height:10px;">
         <div>
    
    <div class="container">
              <div class="pull-center" style="margin-top: -30px;">
    

<div class="container" style="text-align: center;">

    <div class="panel panel-default animated bounceIn" id="login-form" style="max-width: 380px; margin: 170 auto 20px; text-align: left;">

        <div class="panel-heading"><strong>Change Password</strong></div>

        <div class="panel-body">
            
            <form id="" action="" method="post">
                
        <div style="display:none"><input type="hidden" value="" name=""></div>
           

            <div class="form-group">
                Password:<input class="form-control" id=""  name="pass" type="password">                            </div>

            <div class="form-group">
                Confirm Password:<input class="form-control" id="" name="npass" type="password" value="">                            </div>
            <div class="form-group">
                New Password:<input class="form-control" id=""  name="cnpass" type="password" value=""> 
            
<br>
          <center>  <div class="row">
                <div class="col-md-4">
                    <input class="btn btn-large btn-pry" type="submit" name="change" value="Change Password">                </div>
               
            </div></center>

            </form>
        </div>

    </div>

    <br>

           

    
</div>
                 
       
  
        
   
      
    </body>
</html>