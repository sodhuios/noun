<?php
include 'head.php';
?>
  
        <div class="container-left">
    	
               <ul class="menu-vertical">
             <li><a href="../index.php">Home<span></span></a></li>
            <li><a href="dashboard.php">Dashboard<span></span></a></li>
            <li><a href="viewlecturers.php">View Lecturers<span></span></a></li>
            <li><a href="addlecturer.php">Add Lecturer<span></span></a></li>
            <li><a href="addcourse.php">Add Course<span></span></a></li>
            <li><a href="changepass.php">Change Password<span></span></a></li> 
            <li><a href="logout.php">Logout<span></span></a></li>
        </ul>
             
        </div>
        <br>    
        <br><br>
    </body>
</html>